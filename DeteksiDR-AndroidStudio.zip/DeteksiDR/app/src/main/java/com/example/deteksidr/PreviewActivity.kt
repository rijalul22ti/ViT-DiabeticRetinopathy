package com.example.deteksidr

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.RequestBody.Companion.asRequestBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit

class PreviewActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_IMAGE_URI = "extra_image_uri"
        const val EXTRA_TINGKAT_KEPARAHAN = "extra_tingkat_keparahan"
        const val EXTRA_REKOMENDASI_PENANGANAN = "extra_rekomendasi_penanganan"
    }

    private lateinit var ivPreviewBesar: ImageView

    // 1. PINDAHKAN DEKLARASI KE KELAS (PROPERTY)
    private lateinit var btnDeteksi: Button
    private lateinit var progressBar: ProgressBar

    private var uriGambar: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_preview)

        val btnBack = findViewById<ImageButton>(R.id.btnBack)
        ivPreviewBesar = findViewById(R.id.ivPreviewBesar)
        btnDeteksi = findViewById<Button>(R.id.btnDeteksi)
        progressBar = findViewById<ProgressBar>(R.id.progressBar)

        val uriString = intent.getStringExtra(EXTRA_IMAGE_URI)
        if (uriString == null) {
            Toast.makeText(this, "Gambar tidak ditemukan", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        uriGambar = Uri.parse(uriString)
        ivPreviewBesar.setImageURI(uriGambar)

        btnBack.setOnClickListener { finish() }

        btnDeteksi.setOnClickListener {
            uriGambar?.let { uri ->
                prosesDeteksiDenganGambar(uri)
            } ?: run {
                Toast.makeText(this, "Pilih gambar terlebih dahulu", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun prosesDeteksiDenganGambar(uri: Uri) {
        // 1. TAMPILKAN LOADING & NONAKTIFKAN TOMBOL
        btnDeteksi.text = ""
        btnDeteksi.isEnabled = false
        progressBar.visibility = View.VISIBLE

        // Konversi Uri ke File
        val file = getFileFromUri(uri)
        if (file == null) {
            Toast.makeText(this, "Gagal mengolah file gambar", Toast.LENGTH_SHORT).show()

            // Reset loading jika gagal konversi file
            resetLoadingState()
            return
        }

        // Buat RequestBody
        val requestFile = file.asRequestBody("image/*".toMediaTypeOrNull())
        val body = MultipartBody.Part.createFormData("file", file.name, requestFile)

        // Inisialisasi Retrofit dengan OkHttpClient (termasuk timeout)
        val okHttpClient = OkHttpClient.Builder()
            .connectTimeout(60, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .build()

        val retrofit = Retrofit.Builder()
            .baseUrl("http://192.168.43.212:8000/")
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        val apiService = retrofit.create(ApiService::class.java)

        // Kirim Request
        apiService.uploadImage(body).enqueue(object : Callback<DetectionResponse> {
            override fun onResponse(call: Call<DetectionResponse>, response: Response<DetectionResponse>) {
                if (response.isSuccessful && response.body() != null) {
                    val data = response.body()!!

                    val intent = Intent(this@PreviewActivity, DeteksiActivity::class.java).apply {
                        putExtra(EXTRA_IMAGE_URI, uri.toString())
                        putExtra(EXTRA_TINGKAT_KEPARAHAN, data.tingkat_keparahan)
                        putExtra(EXTRA_REKOMENDASI_PENANGANAN, data.rekomendasi_penanganan)
                    }
                    startActivity(intent)
                    finish()
                } else {
                    Toast.makeText(this@PreviewActivity, "Gagal memproses gambar dari server", Toast.LENGTH_SHORT).show()
                    // Reset loading jika response server gagal
                    resetLoadingState()
                }
            }

            override fun onFailure(call: Call<DetectionResponse>, t: Throwable) {
                Toast.makeText(this@PreviewActivity, "Error koneksi: ${t.message}", Toast.LENGTH_SHORT).show()
                // Reset loading jika terjadi network error/timeout
                resetLoadingState()
            }
        })
    }

    // Fungsi pembantu untuk mengembalikan tampilan tombol ke semula
    private fun resetLoadingState() {
        btnDeteksi.text = "Deteksi"
        btnDeteksi.isEnabled = true
        progressBar.visibility = View.GONE
    }

    // Fungsi pembantu konversi URI ke temporary File
    private fun getFileFromUri(uri: Uri): File? {
        return try {
            val inputStream = contentResolver.openInputStream(uri) ?: return null
            val originalBitmap = BitmapFactory.decodeStream(inputStream)
            inputStream.close()

            if (originalBitmap == null) return null

            // 1. Hitung dimensi untuk rasio 1:1 (center crop)
            val width = originalBitmap.width
            val height = originalBitmap.height
            val squareSize = if (width < height) width else height

            val xOffset = (width - squareSize) / 2
            val yOffset = (height - squareSize) / 2

            // 2. Potong gambar menjadi persegi
            val croppedBitmap = Bitmap.createBitmap(
                originalBitmap,
                xOffset,
                yOffset,
                squareSize,
                squareSize
            )

            // 3. Simpan bitmap persegi ke dalam file temporary
            val tempFile = File.createTempFile("upload_cropped_", ".jpg", cacheDir)
            val outputStream = FileOutputStream(tempFile)

            // Simpan dalam format JPEG dengan kualitas 90%
            croppedBitmap.compress(Bitmap.CompressFormat.JPEG, 90, outputStream)
            outputStream.flush()
            outputStream.close()

            // Hapus memori bitmap agar tidak memicu OutOfMemory
            if (croppedBitmap != originalBitmap) {
                originalBitmap.recycle()
            }

            tempFile
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}