package com.example.deteksidr

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity

class SplashActivity : AppCompatActivity() {

    // Durasi Splash Screen (misal: 3000 ms / 3 detik)
    private val SPLASH_TIME_OUT: Long = 1000

    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(R.style.Base_Theme_DeteksiDR)

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        // Delay untuk pindah ke MainActivity
        Handler(Looper.getMainLooper()).postDelayed({
            val intent = Intent(this@SplashActivity, MainActivity::class.java)
            startActivity(intent)
            finish() // Tutup SplashActivity agar pengguna tidak bisa kembali ke splash screen
        }, SPLASH_TIME_OUT)
    }
}