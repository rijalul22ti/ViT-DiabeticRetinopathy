package com.example.deteksidr

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Repository sederhana untuk menyimpan & membaca histori hasil deteksi.
 * Menggunakan SharedPreferences + JSON manual agar tidak perlu dependency tambahan (mis. Room).
 * Untuk aplikasi produksi, sebaiknya diganti dengan Room Database.
 */
object HistoriRepository {

    private const val PREF_NAME = "histori_pref"
    private const val KEY_DATA = "histori_data"

    fun simpan(context: Context, item: HistoriItem) {
        val list = getSemua(context).toMutableList()
        list.add(0, item) // item terbaru ditampilkan paling atas
        val jsonArray = JSONArray()
        for (h in list) {
            val obj = JSONObject()
            obj.put("id", h.id)
            obj.put("hasil", h.hasil)
            obj.put("keterangan", h.keterangan)
            obj.put("tanggal", h.tanggal)
            jsonArray.put(obj)
        }
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_DATA, jsonArray.toString()).apply()
    }

    fun getSemua(context: Context): List<HistoriItem> {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY_DATA, null) ?: return emptyList()
        val result = mutableListOf<HistoriItem>()
        val jsonArray = JSONArray(raw)
        for (i in 0 until jsonArray.length()) {
            val obj = jsonArray.getJSONObject(i)
            result.add(
                HistoriItem(
                    id = obj.getLong("id"),
                    hasil = obj.getString("hasil"),
                    keterangan = obj.getString("keterangan"),
                    tanggal = obj.getString("tanggal")
                )
            )
        }
        return result
    }
}
