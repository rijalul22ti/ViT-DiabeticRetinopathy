package com.example.deteksidr

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class HistoriAdapter(private val items: List<HistoriItem>) :
    RecyclerView.Adapter<HistoriAdapter.HistoriViewHolder>() {

    class HistoriViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val statusDot: View = view.findViewById(R.id.statusDot)
        val tvHasil: TextView = view.findViewById(R.id.tvHasilItem)
        val tvTanggal: TextView = view.findViewById(R.id.tvTanggalItem)

        // Opsional: Jika layout item_histori.xml memiliki tvKeterangan
//        val tvKeterangan: TextView? = view.findViewById(R.id.tvKeteranganItem)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HistoriViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_histori, parent, false)
        return HistoriViewHolder(view)
    }

    override fun onBindViewHolder(holder: HistoriViewHolder, position: Int) {
        val item = items[position]
        holder.tvHasil.text = item.hasil
        holder.tvTanggal.text = item.tanggal
//        holder.tvKeterangan?.text = item.keterangan

        // Indikator warna berdasarkan keparahan hasil
        val warna = when {
            item.hasil.contains("Berat", ignoreCase = true) -> Color.parseColor("#E53935")
            item.hasil.contains("Sedang", ignoreCase = true) -> Color.parseColor("#FB8C00")
            item.hasil.contains("Ringan", ignoreCase = true) -> Color.parseColor("#FDD835")
            else -> Color.parseColor("#43A047")
        }
        holder.statusDot.background?.setTint(warna)
    }

    override fun getItemCount(): Int = items.size
}