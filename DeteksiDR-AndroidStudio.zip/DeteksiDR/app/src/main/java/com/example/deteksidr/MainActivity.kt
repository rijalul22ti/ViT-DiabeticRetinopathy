package com.example.deteksidr

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnDeteksi = findViewById<Button>(R.id.btnDeteksi)
        val btnHistori = findViewById<Button>(R.id.btnHistori)

        // Tombol "Deteksi" -> buka halaman deteksi retinopati
        btnDeteksi.setOnClickListener {
            val intent = Intent(this, InputActivity::class.java)
            startActivity(intent)
        }

        // Tombol "Histori" -> buka halaman riwayat pemeriksaan
        btnHistori.setOnClickListener {
            val intent = Intent(this, HistoriActivity::class.java)
            startActivity(intent)
        }
    }
}