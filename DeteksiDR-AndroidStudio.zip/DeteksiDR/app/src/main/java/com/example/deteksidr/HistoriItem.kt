package com.example.deteksidr

data class HistoriItem(
    val id: Long,
    val hasil: String,
    val keterangan: String,
    val tanggal: String
)