package com.example.deteksidr

import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class HistoriActivity : AppCompatActivity() {

    private lateinit var rvHistori: RecyclerView
    private lateinit var tvEmpty: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_histori)

        val btnBack = findViewById<ImageButton>(R.id.btnBack)
        rvHistori = findViewById(R.id.rvHistori)
        tvEmpty = findViewById(R.id.tvEmpty)

        btnBack.setOnClickListener { finish() }

        rvHistori.layoutManager = LinearLayoutManager(this)
    }

    override fun onResume() {
        super.onResume()
        muatHistori() // Memastikan data terbaru otomatis dimuat
    }

    private fun muatHistori() {
        val data = HistoriRepository.getSemua(this)
        if (data.isEmpty()) {
            rvHistori.visibility = View.GONE
            tvEmpty.visibility = View.VISIBLE
        } else {
            rvHistori.visibility = View.VISIBLE
            tvEmpty.visibility = View.GONE
            rvHistori.adapter = HistoriAdapter(data)
        }
    }
}