package com.example.deteksidr

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class DeteksiActivity : AppCompatActivity() {

    private lateinit var ivGambarHasil: ImageView
    private lateinit var tvTingkatKeparahan: TextView
    private lateinit var tvRekomendasiPenanganan: TextView
    private lateinit var btnBack: ImageButton
    private lateinit var btnSelesai: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_deteksi)

        initView()
        displayData()
        setupAction()
    }

    private fun initView() {
        ivGambarHasil = findViewById(R.id.ivGambarHasil)
        tvTingkatKeparahan = findViewById(R.id.tvTingkatKeparahan)
        tvRekomendasiPenanganan = findViewById(R.id.tvRekomendasiPenanganan)
        btnBack = findViewById(R.id.btnBack)
        btnSelesai = findViewById(R.id.btnSelesai)
    }

    private fun displayData() {
        // Ambil data yang dikirimkan dari PreviewActivity
        val uriString = intent.getStringExtra(PreviewActivity.EXTRA_IMAGE_URI)
        val tingkatKeparahan = intent.getStringExtra(PreviewActivity.EXTRA_TINGKAT_KEPARAHAN) ?: "Data tidak tersedia"
        val rekomendasiPenanganan = intent.getStringExtra(PreviewActivity.EXTRA_REKOMENDASI_PENANGANAN) ?: "Data tidak tersedia"

        // Tampilkan gambar jika URI valid
        if (!uriString.isNullOrEmpty()) {
            val uriGambar = Uri.parse(uriString)
            ivGambarHasil.setImageURI(uriGambar)
        }

        // Tampilkan data hasil deteksi
        tvTingkatKeparahan.text = tingkatKeparahan
        tvRekomendasiPenanganan.text = rekomendasiPenanganan

        // --- PENCATATAN KE HISTORI (Termasuk tanggal, jam & menit) ---
        simpanKeHistori(tingkatKeparahan, rekomendasiPenanganan)
    }

    private fun simpanKeHistori(hasil: String, keterangan: String) {
        // Format tanggal beserta jam dan menit (Contoh: 24 Okt 2023, 14:30)
        val dateFormat = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault())
        val tanggalDanWaktu = dateFormat.format(Date())

        // Buat objek histori item baru
        val historiBaru = HistoriItem(
            id = System.currentTimeMillis(), // Menggunakan timestamp unik sebagai ID
            hasil = hasil,
            keterangan = keterangan,
            tanggal = tanggalDanWaktu
        )

        // Simpan ke SharedPreferences melalui Repository
        HistoriRepository.simpan(this, historiBaru)
    }

    private fun setupAction() {
        btnBack.setOnClickListener {
            finish()
        }

        btnSelesai.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java).apply {
                // Clear semua activity di atas MainActivity dan buka kembali MainActivity
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
            startActivity(intent)
            finish() // Tutup DeteksiActivity
        }
    }
}