package com.example.deteksidr

import okhttp3.MultipartBody
import retrofit2.Call
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part

// Respon dari API
data class DetectionResponse(
    val tingkat_keparahan: String,
    val rekomendasi_penanganan: String
)

// Interface Retrofit
interface ApiService {
    @Multipart
    @POST("api/deteksi") // Sesuaikan endpoint API Anda
    fun uploadImage(
        @Part image: MultipartBody.Part
    ): Call<DetectionResponse>
}
