package com.example.deteksidr

import android.Manifest
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.widget.Button
import android.widget.ImageButton
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class InputActivity : AppCompatActivity() {

    private lateinit var viewFinder: PreviewView
    private lateinit var cameraExecutor: ExecutorService
    private var imageCapture: ImageCapture? = null

    private lateinit var btnPilihGambar: Button
    private lateinit var btnAmbilFoto: Button

    // Launcher untuk memilih gambar dari galeri
    private val pickImageLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null) {
                bukaHalamanPreview(uri)
            } else {
                Toast.makeText(this, "Tidak ada gambar dipilih", Toast.LENGTH_SHORT).show()
            }
        }

    // Launcher untuk meminta izin kamera
    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        if (isGranted) {
            startCamera()
        } else {
            Toast.makeText(this, "Izin kamera ditolak", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_input)
        cameraExecutor = Executors.newSingleThreadExecutor()

        val btnBack = findViewById<ImageButton>(R.id.btnBack)
        viewFinder = findViewById(R.id.cardPreview)
        btnPilihGambar = findViewById(R.id.btnPilihGambar)
        btnAmbilFoto = findViewById(R.id.btnAmbilFoto)

        btnBack.setOnClickListener { finish() }

        btnPilihGambar.setOnClickListener {
            pickImageLauncher.launch("image/*")
        }

        // Tombol nonaktif dulu (sesuai layout) sampai kamera siap di startCamera()
        btnAmbilFoto.setOnClickListener {
            ambilFotoDenganCameraX()
        }

        if (allPermissionsGranted()) {
            startCamera()
        } else {
            requestPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)

        cameraProviderFuture.addListener({
            val cameraProvider: ProcessCameraProvider = cameraProviderFuture.get()

            // 1. Preview UseCase -> ditampilkan pada PreviewView (cardPreview)
            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(viewFinder.surfaceProvider)
            }

            // 2. ImageCapture UseCase -> dipakai saat tombol "Tangkap Gambar" ditekan
            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                .build()

            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(
                    this, cameraSelector, preview, imageCapture
                )
                // Kamera siap -> aktifkan tombol tangkap gambar
                btnAmbilFoto.isEnabled = true
                btnAmbilFoto.alpha = 1.0f
            } catch (xc: Exception) {
                Log.e("CameraX", "Gagal memuat kamera", xc)
                Toast.makeText(this, "Gagal memuat kamera", Toast.LENGTH_SHORT).show()
            }

        }, ContextCompat.getMainExecutor(this))
    }

    /**
     * Mengambil foto langsung dari use case ImageCapture CameraX (bukan intent
     * kamera eksternal) dan menyimpannya lewat MediaStore, lalu lanjut ke
     * halaman preview dengan Uri hasil foto tersebut.
     */
    private fun ambilFotoDenganCameraX() {
        val imageCapture = imageCapture ?: return

        val namaFile = "FOTO_RETINA_${System.currentTimeMillis()}.jpg"
        val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, namaFile)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/DeteksiDR")
        }

        val outputOptions = ImageCapture.OutputFileOptions.Builder(
            contentResolver,
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            contentValues
        ).build()

        btnAmbilFoto.isEnabled = false

        imageCapture.takePicture(
            outputOptions,
            cameraExecutor,
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    runOnUiThread {
                        btnAmbilFoto.isEnabled = true
                        val uriHasil = output.savedUri
                        if (uriHasil != null) {
                            bukaHalamanPreview(uriHasil)
                        } else {
                            Toast.makeText(
                                this@InputActivity,
                                "Gagal menyimpan foto",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                }

                override fun onError(exception: ImageCaptureException) {
                    runOnUiThread {
                        btnAmbilFoto.isEnabled = true
                        Log.e("CameraX", "Gagal mengambil foto", exception)
                        Toast.makeText(
                            this@InputActivity,
                            "Gagal mengambil foto: ${exception.message}",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }
        )
    }

    /**
     * Foto/gambar berhasil didapat (dari kamera CameraX maupun galeri) -> lanjut
     * ke halaman preview input sebelum diproses ke tahap deteksi.
     */
    private fun bukaHalamanPreview(uriGambar: Uri) {
        val intent = Intent(this, PreviewActivity::class.java).apply {
            putExtra(PreviewActivity.EXTRA_IMAGE_URI, uriGambar.toString())
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(intent)
    }

    private fun allPermissionsGranted() = ContextCompat.checkSelfPermission(
        baseContext, Manifest.permission.CAMERA
    ) == PackageManager.PERMISSION_GRANTED

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
    }
}